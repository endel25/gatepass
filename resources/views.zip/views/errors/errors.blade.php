@extends('layouts.admin')
@section('content')
  <div class="page-wrap d-flex flex-row align-items-center" style="background-image: linear-gradient(white, #D3D3D3);">
    <div class="container">
        <div class="row justify-content-center" style="margin-top:15%;">
            <div class="col-md-12 text-center">
                <span class="display-1 d-block">Oops<span style="color:red;">!</span></span>
                &nbsp;
                <div class="mb-4 lead">UnAuthorized Error, Please Contact Administrator.</div>
            </div>
        </div>
    </div>
</div>
@endsection
